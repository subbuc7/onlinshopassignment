package com.firstassesment.onlineshop.service;

import java.util.List;
import com.firstassesment.onlineshop.model.Product;

public interface ProductService {
	 List<Product>getAllProducts();
	 Product addProduct(Product product);
	 List<Product> findByProductName(String productName);
	 List<Product> findByCategory(String category);
	 Product updateProduct(int productId, Product product);
	  int calculateTotalPrce(int productId);
	  void deleteProduct();
}
