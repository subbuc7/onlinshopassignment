package com.firstassesment.onlineshop.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.firstassesment.onlineshop.model.Product;
import com.firstassesment.onlineshop.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@GetMapping("/showAllProducts")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		return new ResponseEntity<>( productService.getAllProducts(),HttpStatus.OK);
		
	}
	
	@PostMapping("/addNewProduct")
	public ResponseEntity< Product> addProduct(@RequestBody Product product){
		
		return new ResponseEntity<>( productService.addProduct(product),HttpStatus.CREATED);
		
	}
	@GetMapping("/getByProductName/{productName}")
	public ResponseEntity<List<Product>> findByProductName(@PathVariable("productName") String productname){
		
		return new ResponseEntity<>( productService.findByProductName(productname),HttpStatus.OK);
		
	}
	@GetMapping("/getByCategory/{category}")
	public ResponseEntity<List<Product>> findByProductId(@PathVariable("category") String category){
		
		return new ResponseEntity<>( productService.findByCategory(category),HttpStatus.OK);
		
	}
    @PutMapping("/updateProduct/{productId}")
    	public ResponseEntity<Product> updateProduct(@PathVariable("productId") int id, @RequestBody Product product) {
    	return new ResponseEntity<>( productService.updateProduct(id, product),HttpStatus.OK);
    		
    	}
    
   @GetMapping("/totalPrice/{productId}")
   public ResponseEntity<Integer> totalPriceForProduct(@PathVariable("productId") int id) {
   	return new ResponseEntity<>( productService.calculateTotalPrce(id),HttpStatus.OK);
   		
   	}
   @DeleteMapping("/removeProduct")
   public  void deleteProductById() {
	   productService.deleteProduct();
	  
   }

}
